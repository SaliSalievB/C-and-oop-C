#include <iostream>
#include "Prime.h"

int main()
{

	PrimeNumber c1(2);
	c1.Print();

	std::cout << c1.getPrimeNumber();


	return 0;
}