#include <iostream>

using namespace std;


/*
int main(){
	cout << "100101";
	cout << endl;
	cout << "0010100";
	cout << endl;
	cout << "55";
	cout << endl;
	cout << "93";
	cout << endl;
	cout << "1CA";
}


int main(){
	int x;
	cout << "Insert number: ";
	
	cin >> x;
	if (x% 2 == 0 ){
	cout << "x is even";
	}
	else{
		cout << "x is odd";
	}
	return 0;
}

int main(){
	int y;
	cout << "insert number: ";
	cin >> y;
	if (y ==1){
		cout << "monday";
	}
	else if (y ==2){
		cout << "tuesday";
	}
	else if (y ==3){
		cout << "wednesday";
	}
	else if (y ==4){
		cout << "thursday";
	}
	else if (y ==5){
		cout << "friday";
	}
	else if (y ==6){
		cout << "saturday";
	}
	else {
		cout << "sunday";
	}
}

int main(){
	int y;
	cout << "insert number: ";
	cin >> y;
	if (y <= 10){
		cout << "slow";
	}
	else if (y <=50){
		cout << "average";
	}
	else if (y <=150){
		cout << "fast";
	}
	else if (y <=1000){
		cout << "ultra fast";
	}
	else if (y >=1001){
		cout <<"eXtream!";
	}

}
*/
