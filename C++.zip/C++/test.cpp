#include <iostream>

using namespace std;
/*1
int main(){
for (int i = 1; i < 2200; i= i*3) {
  cout << i << "\n";
}
}
*/

 /*2
void result(int N)
{    
    
    for (int num = 0; num < N; num++)
    {    
      
        if (num % 3 == 0 && num % 5 == 0)
            cout << num << " ";
    }
}
 
// Driver code
int main()
{    
    // input goes here
    int N = 40;
     
    // Calling function
    result(N);
    return 0;
}
*/
/*3,4
int main () {
   for (int i = 0; i <= 20; i++) {
  cout << i << "\n";
}
 
   return 0;
   
}

int main () {
   for (int i = 20; i > 0; i--) {
  cout << i << "\n";
}

   return 0;
}
*/
/*5
void print_rectangle(int n, int m)
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= m; j++)
        {
            if (i == 1 || i == n ||
                j == 1 || j == m)        
                cout << " * ";            
            else
                cout << " * ";
        }
        cout << endl;
    }
 
}
 

int main()
{
    int rows = 4, columns = 2;
    print_rectangle(rows, columns);
    return 0;
}
*/
/*6
void print_rectangle(int n, int m)
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= m; j++)
        {
            if (i == 1 || i == n ||
                j == 1 || j == m)        
                cout << " + ";            
            else
                cout << " - ";
        }
        cout << endl;
    }
 
}
 

int main()
{
    int rows = 4, columns = 4;
    print_rectangle(rows, columns);
    return 0;
}
*/

