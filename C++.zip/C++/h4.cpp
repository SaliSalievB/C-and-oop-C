#include<iostream>
#include<cmath>
using namespace std;

/*
//Task1
void myFunction() {
	int num;
	cout << "enter num: ";
	cin >> num;

	int sum = 0;

	while (num != 0)
	{
		sum = sum + (num % 10);
		num /= 10;
	}

	cout << "Sum is:" << sum;
}
	
int main(){
	myFunction();

  return 0;
}
//Task2
void myFunction() {
 	int num1;
	int num2;
		cout <<"enter num1: ";
			cin >> num1;
		cout <<"enter num2: ";
			cin >> num2;
		 		cout << pow(num1, num2);
}
int main(){
	myFunction();

  return 0;
}
//Task3
void myFunction() {
	int i,fact=1,number;    
  cout<<"Enter any Number: ";    
 cin>>number;    
  for(i=1;i<=number;i++){    
      fact=fact*i;    
  }    
  cout<<"Factorial of " <<number<<" is: "<<fact<<endl;  
}


int main() {

  myFunction();

  return 0;
}
*/
